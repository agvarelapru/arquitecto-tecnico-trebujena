Volcado de datos SQL de municipios, provincias y comunidades autonomas
======================================================================

Hay tres tablas vinculadas. La latitud y longitud de cada provincia puedes obtener de 
la capital. Lo mismo pasa con las comunidades autonomas.

Hay algo más de información aquí:

http://www.azrodin.com/programacion/sql-con-municipios-provincias-y-comunidades-espanolas
