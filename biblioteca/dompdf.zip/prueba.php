<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>factura pdf</title>
  </head>
  <body>
    <div style="float:right;margin:-8% 5% 0% 0%;color:blue;">
      <h2>FACTURA</h2>
    </div>

    <div style="width:90%; border:2px solid red;margin:10% 5% 0% 5%;height:5mm;background-color:red;"></div>


<div style="border:2px solid red; width:30%; margin:5% 0% 0% 10%;float:left;">
  <h1>Angel Varela</h1>
  <h1>Angel Varela</h1>
  <h1>Angel Varela</h1>
</div>
<div style="border:2px solid red; width:30%; margin:5% 10% 0% 0% ; float:right;">
  <h1>Angel Varela</h1>
  <h1>Angel Varela</h1>
  <h1>Angel Varela</h1>
</div>
<div style="width:90%; border:2px solid red;margin:25% 5% 0% 5%;height:100mm; padding-top:5%;">


    </div>
  </body>
</html>
